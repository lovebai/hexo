package nuc.ss.dao;

public interface UserDao {
    void getUser();
}
