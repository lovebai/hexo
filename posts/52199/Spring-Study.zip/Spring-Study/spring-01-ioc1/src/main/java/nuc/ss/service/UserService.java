package nuc.ss.service;

public interface UserService {
    public void getUser();
}
