package nuc.ss.dao;

public class UserDaoSqlServerImpl implements UserDao{
    public void getUser() {
        System.out.println("SqlServer获取用户数据");
    }
}
