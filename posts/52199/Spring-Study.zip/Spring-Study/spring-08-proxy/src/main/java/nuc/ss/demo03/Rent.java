package nuc.ss.demo03;

public interface Rent {
    public void rent();
}
