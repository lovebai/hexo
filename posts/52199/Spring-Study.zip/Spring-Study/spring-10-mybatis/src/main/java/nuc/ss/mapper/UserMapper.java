package nuc.ss.mapper;

import nuc.ss.pojo.User;

import java.util.List;

public interface UserMapper {
    List<User> selectUser();
}
