package nuc.ss.pojo;

public class Dog {
    public void shout() {
        System.out.println("汪汪汪...");
    }
}
