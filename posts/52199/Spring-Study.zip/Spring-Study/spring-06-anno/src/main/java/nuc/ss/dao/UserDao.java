package nuc.ss.dao;

import org.springframework.stereotype.Repository;

@Repository
public class UserDao {
}
