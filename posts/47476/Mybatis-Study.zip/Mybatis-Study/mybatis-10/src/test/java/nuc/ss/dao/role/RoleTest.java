package nuc.ss.dao.role;

public class RoleTest {
}
